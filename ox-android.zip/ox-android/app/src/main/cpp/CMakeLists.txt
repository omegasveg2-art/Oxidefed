cmake_minimum_required(VERSION 3.22)
project(ox CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

include(FetchContent)
FetchContent_Declare(imgui GIT_REPOSITORY https://github.com/ocornut/imgui.git GIT_TAG v1.90.9 GIT_SHALLOW TRUE)
FetchContent_Declare(dobby GIT_REPOSITORY https://github.com/jmpews/Dobby.git GIT_TAG master GIT_SHALLOW TRUE)
set(DOBBY_GENERATE_SHARED OFF CACHE BOOL "" FORCE)
FetchContent_MakeAvailable(imgui dobby)

add_library(ox SHARED
    main.cpp
    ${imgui_SOURCE_DIR}/imgui.cpp
    ${imgui_SOURCE_DIR}/imgui_draw.cpp
    ${imgui_SOURCE_DIR}/imgui_tables.cpp
    ${imgui_SOURCE_DIR}/imgui_widgets.cpp
    ${imgui_SOURCE_DIR}/backends/imgui_impl_opengl3.cpp)

target_compile_definitions(ox PRIVATE IMGUI_IMPL_OPENGL_ES3)
target_include_directories(ox PRIVATE ${imgui_SOURCE_DIR} ${imgui_SOURCE_DIR}/backends ${dobby_SOURCE_DIR}/include)
target_compile_options(ox PRIVATE -O2 -fvisibility=hidden)
target_link_libraries(ox dobby log EGL GLESv3 android dl)
