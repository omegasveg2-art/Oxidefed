// libox.so — loads into the game process, hooks eglSwapBuffers (render) + AInputQueue_getEvent (touch).
// Inject: System.loadLibrary("ox") from the game's smali / LSPatch / Zygisk. Entry is the constructor below.
#include <jni.h>
#include <pthread.h>
#include <unistd.h>
#include <dlfcn.h>
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <android/input.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include "imgui.h"
#include "imgui_impl_opengl3.h"
#include "dobby.h"
#include "oxide_esp.h"

static struct { std::atomic<float> x{0}, y{0}; std::atomic<bool> down{false}; } g_in;
static EGLBoolean (*o_swap)(EGLDisplay, EGLSurface);
static int32_t (*o_getEvent)(AInputQueue*, AInputEvent**);
static bool g_init = false, g_menu = false;

// ---- config (JSON in the game's data dir) ----
static std::string CfgPath() {
    char n[128] = {0};
    if (FILE* f = fopen("/proc/self/cmdline", "r")) { fread(n, 1, 127, f); fclose(f); }
    return std::string("/data/data/") + n + "/ox.json";
}
static void Save() {
    FILE* f = fopen(CfgPath().c_str(), "w");
    if (!f) return;
    auto& c = ox::cfg;
    fprintf(f, "{\"esp\":%d,\"box\":%d,\"health\":%d,\"name\":%d,\"dist\":%d,\"line\":%d,\"team\":%d,\"maxDist\":%.1f}",
            c.esp, c.box, c.health, c.name, c.dist, c.line, c.team, c.maxDist);
    fclose(f);
}
static bool Key(const char* s, const char* k, double& v) {
    char key[32]; snprintf(key, sizeof key, "\"%s\":", k);
    const char* p = strstr(s, key);
    if (!p) return false;
    v = atof(p + strlen(key));
    return true;
}
static void Load() {
    FILE* f = fopen(CfgPath().c_str(), "r");
    if (!f) return;
    char b[512] = {0}; fread(b, 1, sizeof b - 1, f); fclose(f);
    auto& c = ox::cfg; double v;
#define B(n) if (Key(b, #n, v)) c.n = v != 0;
    B(esp) B(box) B(health) B(name) B(dist) B(line) B(team)
#undef B
    if (Key(b, "maxDist", v)) c.maxDist = (float)v;
}

// ---- ui ----
static void Ui() {
    ImGui::SetNextWindowPos(ImVec2(20, 20), ImGuiCond_Once);
    ImGui::Begin("##ox_btn", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoBackground);
    if (ImGui::Button("OX")) g_menu = !g_menu;
    ImGui::End();
    if (!g_menu) return;
    ImGui::SetNextWindowPos(ImVec2(120, 60), ImGuiCond_Once);
    ImGui::SetNextWindowSize(ImVec2(560, 460), ImGuiCond_Once);
    if (ImGui::Begin("OX", &g_menu)) {
        if (ImGui::BeginTabBar("tabs")) {
            if (ImGui::BeginTabItem("ESP")) { ox::Menu(); ImGui::EndTabItem(); }
            if (ImGui::BeginTabItem("CONFIG")) {
                if (ImGui::Button("Save")) Save();
                ImGui::SameLine();
                if (ImGui::Button("Load")) Load();
                ImGui::EndTabItem();
            }
            ImGui::EndTabBar();
        }
    }
    ImGui::End();
}

// ---- hooks ----
static EGLBoolean h_swap(EGLDisplay d, EGLSurface s) {
    EGLint w = 0, h = 0;
    eglQuerySurface(d, s, EGL_WIDTH, &w);
    eglQuerySurface(d, s, EGL_HEIGHT, &h);
    if (w > 0 && h > 0) {
        if (!g_init) {
            ImGui::CreateContext();
            ImGuiIO& io = ImGui::GetIO();
            io.IniFilename = nullptr;
            io.FontGlobalScale = h / 720.f > 1.f ? h / 720.f : 1.f;
            ImGui::StyleColorsDark();
            ImGui_ImplOpenGL3_Init("#version 300 es");
            Load();
            g_init = true;
        }
        ImGuiIO& io = ImGui::GetIO();
        io.DisplaySize = ImVec2((float)w, (float)h);
        io.DeltaTime = 1.f / 60.f;
        io.AddMousePosEvent(g_in.x, g_in.y);
        io.AddMouseButtonEvent(0, g_in.down);
        ImGui_ImplOpenGL3_NewFrame();
        ImGui::NewFrame();
        ox::Esp();
        Ui();
        ImGui::Render();
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    }
    return o_swap(d, s);
}

static int32_t h_getEvent(AInputQueue* q, AInputEvent** ev) {
    int32_t r = o_getEvent(q, ev);
    if (r >= 0 && ev && *ev && AInputEvent_getType(*ev) == AINPUT_EVENT_TYPE_MOTION) {
        int a = AMotionEvent_getAction(*ev) & AMOTION_EVENT_ACTION_MASK;
        g_in.x = AMotionEvent_getX(*ev, 0);
        g_in.y = AMotionEvent_getY(*ev, 0);
        if (a == AMOTION_EVENT_ACTION_DOWN) g_in.down = true;
        else if (a == AMOTION_EVENT_ACTION_UP || a == AMOTION_EVENT_ACTION_CANCEL) g_in.down = false;
    }
    return r;
}

static void* worker(void*) {
    while (!dlopen("libil2cpp.so", RTLD_NOW | RTLD_NOLOAD)) sleep(1);
    sleep(5);
    void* egl = dlopen("libEGL.so", RTLD_NOW);
    void* an = dlopen("libandroid.so", RTLD_NOW);
    void* sw = egl ? dlsym(egl, "eglSwapBuffers") : nullptr;
    void* ge = an ? dlsym(an, "AInputQueue_getEvent") : nullptr;
    if (sw) DobbyHook(sw, (void*)h_swap, (void**)&o_swap);
    if (ge) DobbyHook(ge, (void*)h_getEvent, (void**)&o_getEvent);
    return nullptr;
}

__attribute__((constructor)) static void ox_ctor() {
    pthread_t t;
    pthread_create(&t, nullptr, worker, nullptr);
    pthread_detach(t);
}
